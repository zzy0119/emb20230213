#ifndef __THR_DATA_H__
#define __THR_DATA_H__

#include "media_lib.h"

/*
chnid:要发送的频道号
return:成功与否的状态
 */
int thr_data_create(chnid_t chnid);

#endif

